package com.senai.atvPontuada.exception;

public class EmailJaCadastradoException extends RuntimeException {
    public EmailJaCadastradoException(String message){
        super(message);
    }
}
